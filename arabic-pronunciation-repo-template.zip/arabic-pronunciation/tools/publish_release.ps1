param(
  [string]$Tag = "v1.0.0",
  [string]$Title = "Arabic letters (WAV, MSA male)",
  [string]$Zip = "arabic_pronunciation_letters.zip"
)

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  Write-Error "GitHub CLI 'gh' is required. Install from https://cli.github.com/"
  exit 1
}

if (-not (Test-Path $Zip)) {
  Write-Error "ZIP not found: $Zip"
  exit 1
}

gh release create $Tag $Zip --title $Title --notes "Auto-generated Arabic letters WAV pack."
