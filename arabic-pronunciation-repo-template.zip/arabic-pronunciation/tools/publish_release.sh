#!/usr/bin/env bash
set -euo pipefail

TAG="${1:-v1.0.0}"
TITLE="${2:-Arabic letters (WAV, MSA male)}"
ZIP="${3:-arabic_pronunciation_letters.zip}"

if ! command -v gh >/dev/null 2>&1; then
  echo "GitHub CLI 'gh' is required. Install from https://cli.github.com/"
  exit 1
fi

if [ ! -f "$ZIP" ]; then
  echo "ZIP not found: $ZIP"
  exit 1
fi

gh release create "$TAG" "$ZIP" --title "$TITLE" --notes "Auto-generated Arabic letters WAV pack."
